<template>
  <div class="flex flex-col items-center p-6 min-h-screen">
    <h2 class="text-2xl font-bold mb-4 ">Calculateur CO₂</h2>
    <CO2Form />
  </div>
</template>

<script setup lang="ts">
import CO2Form from '@/components/forms/CO2Form.vue'
</script>
